---------------------------------------------------------------------------
-- @author Gregor Best
-- @copyright 2008 Gregor Best
-- @release v3.4.15
---------------------------------------------------------------------------

--- Dummy function for floating layout
module("awful.layout.suit.floating")

function arrange()
end

name = "floating"
